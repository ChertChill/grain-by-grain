CREATE OR REPLACE FUNCTION audit_users_update()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'UPDATE' AND (OLD.* IS DISTINCT FROM NEW.*) THEN
        INSERT INTO users_audit (
            operation_type,
			user_id,
			changed_by,
			old_email,
			new_email,
			old_password_hash,
			new_password_hash,
			old_full_name,
			new_full_name
        ) VALUES (
            'UPDATE',
            OLD.user_id,
			NEW.user_id,
            OLD.email,
			NEW.email,
            OLD.password_hash,
			NEW.password_hash,
            OLD.full_name,
			NEW.full_name
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;