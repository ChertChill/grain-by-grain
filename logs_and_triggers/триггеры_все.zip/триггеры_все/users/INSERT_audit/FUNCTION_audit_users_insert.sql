CREATE OR REPLACE FUNCTION audit_users_insert()
RETURNS TRIGGER AS $$
BEGIN
    -- Вставляем запись в таблицу аудита для операции INSERT
    INSERT INTO users_audit (
        operation_type,
        user_id,
        changed_by,
        old_email,
        new_email,
        old_password_hash,
        new_password_hash,
        old_full_name,
        new_full_name
    ) VALUES (
        'INSERT',
        NEW.user_id,
        NEW.user_id, -- Предполагаем, что пользователь создает сам себя, иначе нужно передать ID текущего пользователя
        NULL, -- Для INSERT старые значения пустые
        NEW.email,
        NULL, -- Для INSERT старые значения пустые
        NEW.password_hash,
        NULL, -- Для INSERT старые значения пустые
        NEW.full_name
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;