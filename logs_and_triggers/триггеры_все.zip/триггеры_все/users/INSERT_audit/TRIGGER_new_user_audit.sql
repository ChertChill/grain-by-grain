-- Trigger: new_user_audit

-- DROP TRIGGER IF EXISTS new_user_audit ON public.users;

CREATE OR REPLACE TRIGGER new_user_audit
    AFTER INSERT
    ON public.users
    FOR EACH ROW
    EXECUTE FUNCTION public.audit_users_insert();