
CREATE TABLE users_audit (
    audit_id SERIAL PRIMARY KEY,
    operation_type VARCHAR(10) NOT NULL,
    user_id INT NOT NULL REFERENCES users(user_id),
    changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, 
    changed_by INT NOT NULL REFERENCES users(user_id),
    old_email VARCHAR(100),
    new_email VARCHAR(100) NOT NULL,
    old_password_hash VARCHAR(255),
    new_password_hash VARCHAR(255) NOT NULL,
    old_full_name VARCHAR(100),
    new_full_name VARCHAR(100) NOT NULL
);