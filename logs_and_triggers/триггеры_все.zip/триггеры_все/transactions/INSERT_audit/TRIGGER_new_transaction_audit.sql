-- Trigger: new_user_audit

-- DROP TRIGGER IF EXISTS new_user_audit ON public.users;

CREATE OR REPLACE TRIGGER new_transaction_audit
    AFTER INSERT
    ON public.transactions
    FOR EACH ROW
    EXECUTE FUNCTION public.audit_transactions_insert();