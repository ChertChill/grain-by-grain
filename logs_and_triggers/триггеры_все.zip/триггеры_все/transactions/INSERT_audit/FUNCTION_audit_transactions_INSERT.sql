CREATE OR REPLACE FUNCTION audit_transactions_insert()
RETURNS TRIGGER AS $$
BEGIN
    -- Вставляем запись в таблицу аудита для операции INSERT
    INSERT INTO transactions_audit (
	
        operation_type,
		transaction_id,
		type_id,
		user_id,
		--created_at,
		changed_by, -- Предполагаем, что пользователь создает сам себя, иначе нужно передать ID текущего пользователя
		account_number,
		recipient_number,
		
		-- Для INSERT старым значениям присваивается NULL
		amount,
		comment,
		status_id,
		legal_type_id,
		transaction_date,  
		bank_id,
		recipient_tin,
		category_id,
		recipient_phone,
        
		new_amount,
		new_comment,
		new_status_id,
		new_legal_type_id,
		new_transaction_date,  
		new_bank_id,
		new_recipient_tin,
		new_category_id,
		new_recipient_phone
	
	) VALUES (
        'INSERT',
        NEW.transaction_id,
		NEW.type_id,
        NEW.user_id,
		--created_at,
		NEW.user_id,
		NEW.account_number,
		NEW.recipient_number,

		NULL,	--amount
		NULL,	--comment
		NULL,	--status_id
		NULL,	--legal_type_id
		NULL,	--transaction_date
		NULL,	--bank_id
		NULL,	--recipient_tin
		NULL,	--category_id
		NULL,	--recipient_phone
		
		NEW.amount,				--new_amount
		NEW.comment,			--new_comment
		NEW.status_id,			--new_status_id
		NEW.legal_type_id,		--new_legal_type_id
		NEW.transaction_date,	--new_transaction_date
		NEW.bank_id,				--new_bank_id
		NEW.recipient_tin,		--new_recipient_tin
		NEW.category_id,		--new_category_id
		NEW.recipient_phone		--new_recipient_phone

    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;