
CREATE TABLE transactions_audit (
    
	-- Поля таблицы для аудита
	audit_id SERIAL PRIMARY KEY,
    operation_type VARCHAR(10) NOT NULL,
	
	
	-- Поля таблицы transactions, которые не меняются
	transaction_id INT NOT NULL REFERENCES transactions(transaction_id),
	type_id INT NOT NULL REFERENCES transaction_types(type_id),
	user_id BIGINT NOT NULL REFERENCES users(user_id),
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	changed_by INT NOT NULL REFERENCES users(user_id),
	account_number VARCHAR(50) NOT NULL,
	recipient_number VARCHAR(50) NOT NULL,
	
	
	-- Параметры, доступные для редактирования (старые значения)
	amount DECIMAL(12, 2),
	comment TEXT,
	status_id INT REFERENCES transaction_status(status_id),
	legal_type_id INT REFERENCES legal_types(legal_type_id),
	transaction_date DATE ,  
	bank_id INT REFERENCES banks (bank_id),
	recipient_tin VARCHAR(11),
	category_id INT REFERENCES categories(category_id),
	recipient_phone VARCHAR(16),
	
	
	--Поля для сохранения новых значений
	new_legal_type_id INT REFERENCES legal_types(legal_type_id),
	new_transaction_date DATE,  
	new_comment TEXT,
	new_amount DECIMAL(12, 2),
	new_status_id INT REFERENCES transaction_status(status_id),
	new_bank_id INT REFERENCES banks (bank_id),
	new_recipient_tin VARCHAR(11),
	new_category_id INT REFERENCES categories(category_id),
	new_recipient_phone VARCHAR(16)
	
);