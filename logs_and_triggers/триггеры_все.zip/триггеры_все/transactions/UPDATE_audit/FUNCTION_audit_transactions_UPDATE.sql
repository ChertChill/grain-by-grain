CREATE OR REPLACE FUNCTION audit_transactions_update()
RETURNS TRIGGER AS $$
BEGIN
    
	IF TG_OP = 'UPDATE' AND (OLD.* IS DISTINCT FROM NEW.*) THEN
		-- Вставляем запись в таблицу аудита для операции INSERT
		INSERT INTO transactions_audit (
		
			operation_type,
			transaction_id,
			type_id,
			user_id,
			--created_at,
			changed_by, -- Предполагаем, что пользователь создает сам себя, иначе нужно передать ID текущего пользователя
			account_number,
			recipient_number,
			
			-- Для INSERT старым значениям присваивается NULL
			amount,
			comment,
			status_id,
			legal_type_id,
			transaction_date,  
			bank,
			recipient_tin,
			category_id,
			phone,
			
			new_amount,
			new_comment,
			new_status_id,
			new_legal_type_id,
			new_transaction_date,  
			new_bank,
			new_recipient_tin,
			new_category_id,
			new_phone
		
		) VALUES (
			'UPDATE',
			NEW.transaction_id,
			NEW.type_id,
			NEW.user_id,
			--created_at,
			NEW.user_id,
			NEW.account_number,
			NEW.recipient_number,

			OLD.amount,				--amount
			OLD.comment,			--comment
			OLD.status_id,			--status_id
			OLD.legal_type_id,		--legal_type_id
			OLD.transaction_date,	--transaction_date
			OLD.bank,				--bank
			OLD.recipient_tin,		--recipient_tin
			OLD.category_id,		--category_id
			OLD.phone,				--phone
			
			NEW.amount,				--new_amount
			NEW.comment,			--new_comment
			NEW.status_id,			--new_status_id
			NEW.legal_type_id,		--new_legal_type_id
			NEW.transaction_date,	--new_transaction_date
			NEW.bank,				--new_bank
			NEW.recipient_tin,		--new_recipient_tin
			NEW.category_id,		--new_category_id
			NEW.phone				--new_phone

		);
    END IF;
	
	RAISE NOTICE E'TRIGGER update\n Value of transaction_id : %', NEW.transaction_id;
	
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;