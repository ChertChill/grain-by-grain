

CREATE OR REPLACE TRIGGER update_transaction_audit
    AFTER UPDATE
    ON public.transactions
    FOR EACH ROW
    EXECUTE FUNCTION public.audit_transactions_update();