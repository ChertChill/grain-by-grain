CREATE OR REPLACE FUNCTION audit_transactions_delete()
RETURNS TRIGGER AS $$
BEGIN
    
	UPDATE transactions
	SET status_id = 6
	WHERE transaction_id = OLD.transaction_id;
	
	INSERT INTO transactions_audit (
	
		operation_type,
		transaction_id,
		type_id,
		user_id,
		--created_at,
		changed_by, -- Предполагаем, что пользователь удаляет свои транзакции, иначе нужно передать ID текущего пользователя
		account_number,
		recipient_number,
		
		-- Для DELETE старым значениям присваиваются текущие значения
		amount,
		comment,
		status_id,
		legal_type_id,
		transaction_date,  
		bank_id,
		recipient_tin,
		category_id,
		recipient_phone,
		
		-- Для DELETE новым значениям присваивается NULL		
		new_amount,
		new_comment,
		new_status_id,
		new_legal_type_id,
		new_transaction_date,  
		new_bank_id,
		new_recipient_tin,
		new_category_id,
		new_recipient_phone
	
	) VALUES (
		'DELETE',
		OLD.transaction_id,
		OLD.type_id,
		OLD.user_id,
		--created_at,
		OLD.user_id,
		OLD.account_number,
		OLD.recipient_number,

		OLD.amount,				--amount
		OLD.comment,			--comment
		--OLD.status_id,			--status_id
		6, --Платеж отменен
		OLD.legal_type_id,		--legal_type_id
		OLD.transaction_date,	--transaction_date
		OLD.bank_id,				--bank
		OLD.recipient_tin,		--recipient_tin
		OLD.category_id,		--category_id
		OLD.recipient_phone,				--phone
		
		NULL,				--new_amount
		NULL,			--new_comment
		NULL,			--new_status_id
		NULL,		--new_legal_type_id
		NULL,	--new_transaction_date
		NULL,				--new_bank
		NULL,		--new_recipient_tin
		NULL,		--new_category_id
		NULL				--new_phone
	);
	
	RAISE NOTICE E'Trigger DELETE\nValue of transaction_id : %', OLD.transaction_id;
	
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;