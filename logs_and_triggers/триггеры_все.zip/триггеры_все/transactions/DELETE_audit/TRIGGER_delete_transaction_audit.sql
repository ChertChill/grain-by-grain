

CREATE OR REPLACE TRIGGER delete_transactions_audit
    BEFORE DELETE
    ON public.transactions
    FOR EACH ROW
    EXECUTE FUNCTION public.audit_transactions_delete();